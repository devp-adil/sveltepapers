import { c as create_ssr_component } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const Contacte = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<html lang="${"en"}" class="${"dark"}"><head></head>
    <body><div class="${"container-sm"}">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere modi, autem perspiciatis ipsa omnis odit laboriosam vero vel possimus nostrum. Voluptatum deserunt quod incidunt ab et iusto, cum rerum earum?
        </div></body></html>`;
});
export { Contacte as default };
