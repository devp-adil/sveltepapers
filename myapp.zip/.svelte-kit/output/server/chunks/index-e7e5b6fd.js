import { c as create_ssr_component } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const Routes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<title>Index</title>
<h2>My Page</h2>`;
});
export { Routes as default };
