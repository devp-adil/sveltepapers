import { c as create_ssr_component, a as add_attribute } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const Contact = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let name;
  let email;
  return `${`${``}`}
<br>
<h3>Contact Page</h3>
<div container-md><div class="${"row"}"><div class="${"sm-4 col"}"><form><input type="${"text"}" name="${"name"}" placeholder="${"name"}"${add_attribute("value", name, 0)}>
            <input type="${"text"}" name="${"email"}" placeholder="${"email"}"${add_attribute("value", email, 0)}>
            <button type="${"submit"}" class="${"btn-secondary"}">Submit</button></form></div></div></div>`;
});
export { Contact as default };
