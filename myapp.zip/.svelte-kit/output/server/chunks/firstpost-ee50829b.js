import { c as create_ssr_component } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const Firstpost = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<h2>First Post</h2>
<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perferendis sequi qui quaerat maiores ipsum ad eaque ullam fugiat obcaecati expedita, et accusamus? Exercitationem dignissimos vel autem hic repudiandae soluta tempora!
</p>`;
});
export { Firstpost as default };
