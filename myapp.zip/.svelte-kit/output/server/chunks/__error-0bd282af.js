import { c as create_ssr_component } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const _error = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div style="${"border-radius:10px;border:1px solid"}"><h1>Error Page Not Found</h1></div>`;
});
export { _error as default };
