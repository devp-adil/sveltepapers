import { c as create_ssr_component, e as escape } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
const load = ({ page }) => {
  const id = page.params.id;
  return { props: { id } };
};
const U5Bidu5D = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { id } = $$props;
  if ($$props.id === void 0 && $$bindings.id && id !== void 0)
    $$bindings.id(id);
  return `${escape(id)}
<h2>ID blog</h2>`;
});
export { U5Bidu5D as default, load };
