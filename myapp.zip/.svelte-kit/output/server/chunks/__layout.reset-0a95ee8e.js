import { c as create_ssr_component } from "./app-c58e62d5.js";
import "@sveltejs/kit/ssr";
var __layout_reset_svelte_svelte_type_style_lang = "";
const css = {
  code: "nav.svelte-11tuul6{background-color:red}h3.svelte-11tuul6{color:red}",
  map: null
};
const _layout_reset = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<nav class="${"svelte-11tuul6"}"><ul><li><a href="${"/about"}">some</a></li></ul></nav>

<h3 class="${"svelte-11tuul6"}">You are in contact Page</h3>

${slots.default ? slots.default({}) : ``}`;
});
export { _layout_reset as default };
