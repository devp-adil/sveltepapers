import "@sveltejs/kit/ssr";
export { i as init, r as render } from "./chunks/app-c58e62d5.js";
