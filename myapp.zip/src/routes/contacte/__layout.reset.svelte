<nav>
    <ul>
        <li>
            <a href="/about">some</a>
        </li>
    </ul>
</nav>

<h3>You are in contact Page</h3>

<slot></slot>





<style>
    nav
    {
        background-color:red;
    }
    h3
    {
        color: red;
    }
</style>


