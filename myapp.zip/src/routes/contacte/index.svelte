<html lang="en" class="dark">
    <head></head>
    <body>
        <div class="container-sm">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere modi, autem perspiciatis ipsa omnis odit laboriosam vero vel possimus nostrum. Voluptatum deserunt quod incidunt ab et iusto, cum rerum earum?
        </div>
    </body>    
</html>
