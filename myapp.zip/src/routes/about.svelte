<title>About Us pages</title>
<h2>About page</h2>


<div class="row flex-middle">
    <div class="sm-12 col">
    <p class="col-7 aligned">
        <img src="https://unsplash.it/200" class="float-left" alt="myimage">
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque accusamus repellat sit ab expedita. Quo ex nihil voluptatem praesentium est officiis voluptate animi autem. Odit corporis error sequi accusantium praesentium?
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque accusamus repellat sit ab expedita. Quo ex nihil voluptatem praesentium est officiis voluptate animi autem. Odit corporis error sequi accusantium praesentium?
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque accusamus repellat sit ab expedita. Quo ex nihil voluptatem praesentium est officiis voluptate animi autem. Odit corporis error sequi accusantium praesentium?
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque accusamus repellat sit ab expedita. Quo ex nihil voluptatem praesentium est officiis voluptate animi autem. Odit corporis error sequi accusantium praesentium?
       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cumque accusamus repellat sit ab expedita. Quo ex nihil voluptatem praesentium est officiis voluptate animi autem. Odit corporis error sequi accusantium praesentium?
        
      </p>
    </div>
  </div>



